<!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
    <meta property="og:description" content="Website resmi Linux Hosting Live">
    <meta property="og:image" content="../../set_xd/img/images.jpg">
    <link rel="shorcut icon" href="../../set_xd/img/icon.png">
    <link rel="stylesheet" href="../../set_xd/css/style.css">
    <link rel="stylesheet" href="../../set_xd/css/animate.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato&display=swap">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://alphahosting.id/v2/set_xd/js/editblink.js"></script>
    <title>LINUX HOSTING</title>
  </head>
  <body style='background: #fff;' oncontextmenu='return false;'>
  <div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>claim17.xyz</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>eventnew.xyz</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>eventz21.xyz</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>eventz6.xyz</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>guice.ml</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>guice.cf</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>hol69.ga</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>get76.ga</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>claims.ga</div>
    </div><div class='kotak-konten animated flipInX'>
      <div class='konten2'>Aktif <i style='color:green' class='fa fa-check'></i></div>
      <div class='txt6'>claims.gq</div>
    </div>  </body>
</html>